# krmfnsops
KRM function (Kustomize) to decrypt SOPS encoded resources
